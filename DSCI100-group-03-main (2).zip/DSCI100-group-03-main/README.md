# dsci-100-project_003

Project repository for DSCI-100

DSCI 100, section 005, group 03

**Authors:** Margarita Kapustina, Muhammad Shahbaz Murtaza, Linda Chu, Brendan Yuen

**Dataset:** [2017 Stellar Classification (SDSS17)](https://www.kaggle.com/datasets/fedesoriano/stellar-classification-dataset-sdss17)
